Python API for Entropy Market

Get Started

```
make setup
```

Examples in notebooks

```
cd notebooks
jupyter notebooks
```

Run a simple marketmaker

```
cd entropy
python simplemarketmaker.py
```
