Python API for Entropy Markets (pyentropy)
