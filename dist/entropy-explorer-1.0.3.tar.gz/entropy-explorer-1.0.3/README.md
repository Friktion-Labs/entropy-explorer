Python API for Entropy Markets (entropy-explorer)
